# Final Project

This contains the first 50% of the final project. Use the make file by typing make henry_caleb_quickSort, and clean up by using make clean.
Use the executable by typing ./henry_caleb_quickSort 'yourinput'.txt 'youroutput.txt
